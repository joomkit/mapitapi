<?php
/**
 * mapitapi plugin for Craft CMS 3.x
 *
 * does map stuff
 *
 * @link      https://www.joomkit.co.uk
 * @copyright Copyright (c) 2021 Alan Sparkes
 */

/**
 * @author    Alan Sparkes
 * @package   Mapitapi
 * @since     1.0.0
 */
return [
    'mapitapi plugin loaded' => 'mapitapi plugin loaded',
];

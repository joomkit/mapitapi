<?php
/**
 * mapitapi plugin for Craft CMS 3.x
 *
 * def
 *
 * @link      https://www.joomkit.co.uk
 * @copyright Copyright (c) 2021 Alan Sparkes
 */

namespace joomkit\mapitapi\jobs;


use craft\console\Application as ConsoleApplication;
use craft\db\QueryAbortedException;
use craft\errors\ElementNotFoundException;
use yii\base\ErrorException;
use joomkit\mapitapi\Mapitapi;
use craft\base\Component;
use Craft;
use craft\queue\BaseJob;

use craft\db\Paginator;
use craft\elements\Entry;
use craft\elements\db\ElementQuery;
use craft\helpers\App;
use yii\base\Exception;


/**
 * @author    Alan Sparkes
 * @package   Mapitapi
 * @since     1.0.0
 */
class DeleteFundingData extends BaseJob
{
    // Public Properties
    // =========================================================================

    /**
     * @var string
     */
    public $areaId;
    public $geoJson;
    public $elementIds;
    private $mapAPIkey;
    // Public Methods
    // =========================================================================

    /**
     * @inheritdoc
     */
    public function execute($queue)
    {

        $elementIds = $this->elementIds ?? [];
        $totalElements = count($elementIds);
        $currentElement = 0;
        foreach ($elementIds as $id) {
//            $element = Entry::find()->anyStatus()->id($id)->one();
            //if (!$element) continue;
            // process the current element …
            try {
                $element = Entry::find()->anyStatus()->id($id)->one();
                Craft::$app->getElements()->deleteElement($element);

            } catch (Exception $e) {
                echo '[error]: '
                    . $e->getMessage()
                    . 'exception while processing '
                    . $currentElement . '/' . $totalElements
                    . ' - processing asset: ' . $element->title
                    . ' from field: ' . $element->lsoacode . PHP_EOL;

            }
        }


    }

    // Protected Methods
    // =========================================================================

    /**
     * @inheritdoc
     */
    protected function defaultDescription(): string
    {
        return Craft::t('mapitapi', 'Deleting open funding data');
    }
}
